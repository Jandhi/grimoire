from data.asset import Asset
from style.substyle import Substyle

class Style(Asset):
    substyles : list[Substyle]