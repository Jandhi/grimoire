# after terrain manipulation, we might want to update districts
# TODO