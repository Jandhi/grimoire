from structures.nbt.nbt_asset import NBTAsset

class Room(NBTAsset):
    pass