 # How to run the generator
pipenv install
pipenv run python placement/tests/test_everything.py

You may have to switch python to python3 or whatever your local version is