class BuildingType:
    pass