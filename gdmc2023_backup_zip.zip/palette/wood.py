oak = 'oak'
spruce = 'spruce'
birch = 'birch'
dark_oak = 'dark_oak'
acacia = 'acacia'
jungle = 'jungle'
mangrove = 'mangrove'
warped = 'warped'
crimson = 'crimson'

woods = [
    oak,
    spruce,
    birch,
    dark_oak,
    acacia,
    jungle,
    warped,
    crimson,
]

