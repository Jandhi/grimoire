from data.asset import Asset

class Forest(Asset):
    tree_dict : dict
    tree_palette : dict[dict]
    tree_density: int