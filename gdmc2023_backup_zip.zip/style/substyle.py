from data.asset import Asset

class Substyle(Asset):
    input_palette : dict[str, str]