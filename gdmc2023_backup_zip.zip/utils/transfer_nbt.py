from data.load_types import load_types

load_types()

my_nbt_path = 'C:\Users\jando\AppData\Roaming\.minecraft\saves\NBTs\generated\minecraft\structures'

nbt_name = ''
nbt_type = ''



# TODO create default files for nbts